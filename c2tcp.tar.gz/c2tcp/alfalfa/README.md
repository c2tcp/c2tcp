Alfalfa is a research project to build a videoconferencing system
that works well over cellular wireless networks. It uses the same
SSP protocol as Mosh, the mobile shell.
